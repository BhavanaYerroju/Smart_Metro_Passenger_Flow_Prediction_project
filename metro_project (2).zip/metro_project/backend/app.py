"""
app.py
------
Flask backend for the Metro OD Passenger Flow Prediction & Operational
Decision Support System.

Run:
    python backend/app.py

Then open http://127.0.0.1:5000/ in a browser.
"""

import os
import sys
import sqlite3
from datetime import datetime

import numpy as np
import pandas as pd
import joblib
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from werkzeug.security import check_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BASE_DIR)
sys.path.append(os.path.join(ROOT_DIR, "model"))

from preprocessing import STATIONS, WEATHER_OPTIONS, WINDOW, single_prediction_features  # noqa: E402

DB_PATH = os.path.join(ROOT_DIR, "database", "metro.db")
DATASET_PATH = os.path.join(ROOT_DIR, "dataset", "metro_od_dataset.csv")
KERAS_MODEL_PATH = os.path.join(ROOT_DIR, "model", "adaptive_fusion_model.h5")
SCALER_PATH = os.path.join(ROOT_DIR, "model", "scaler.pkl")
FALLBACK_MODEL_PATH = os.path.join(ROOT_DIR, "model", "fallback_model.pkl")

FRONTEND_DIR = os.path.join(ROOT_DIR, "frontend")

app = Flask(
    __name__,
    template_folder=os.path.join(FRONTEND_DIR, "templates"),
    static_folder=os.path.join(FRONTEND_DIR, "static"),
)
app.secret_key = "college-project-demo-secret-key-change-in-production"

# ---------------------------------------------------------------------
# Load dataset (used for historical lookups / recent history windows)
# ---------------------------------------------------------------------
DATASET = pd.read_csv(DATASET_PATH)

# ---------------------------------------------------------------------
# Load prediction model — prefers the real Keras Adaptive Fusion Network
# if it has been trained (model/train_model.py); otherwise falls back to
# the RandomForest model so the app is always runnable end-to-end.
# ---------------------------------------------------------------------
MODEL_MODE = None
KERAS_MODEL = None
SCALER = None
FALLBACK_MODEL = None

if os.path.exists(KERAS_MODEL_PATH) and os.path.exists(SCALER_PATH):
    try:
        import tensorflow as tf
        KERAS_MODEL = tf.keras.models.load_model(KERAS_MODEL_PATH)
        SCALER = joblib.load(SCALER_PATH)
        MODEL_MODE = "adaptive_fusion_keras"
    except Exception as e:
        print(f"Could not load Keras model ({e}); falling back.")

if MODEL_MODE is None and os.path.exists(FALLBACK_MODEL_PATH):
    FALLBACK_MODEL = joblib.load(FALLBACK_MODEL_PATH)
    MODEL_MODE = "fallback_random_forest"

print(f"[app.py] Prediction model in use: {MODEL_MODE}")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def crowd_level(count: int) -> str:
    if count >= 500:
        return "High"
    if count >= 250:
        return "Medium"
    return "Low"


def recommendation_for(level: str) -> str:
    return {
        "High": "Increase train frequency / deploy additional staff",
        "Medium": "Monitor closely; keep standby train ready",
        "Low": "Normal operations sufficient",
    }[level]


def recent_history(origin, destination, before_dt=None, n=WINDOW):
    """Return the last n known passenger counts for this OD pair from
    the dataset, used as the sequence input to the model."""
    sub = DATASET[
        (DATASET["Origin_Station"] == origin) & (DATASET["Destination_Station"] == destination)
    ].copy()
    if sub.empty:
        return [200] * n  # cold-start fallback
    sub["_dt"] = pd.to_datetime(sub["Date"] + " " + sub["Time"])
    sub = sub.sort_values("_dt")
    if before_dt is not None:
        sub = sub[sub["_dt"] <= before_dt]
    counts = sub["Passenger_Count"].tail(n).tolist()
    if len(counts) < n:
        counts = [counts[0] if counts else 200] * (n - len(counts)) + counts
    return counts


def predict_flow(origin, destination, date_str, time_str, weather, temperature, holiday):
    hist = recent_history(origin, destination)
    seq, origin_id, dest_id, weather_id, num = single_prediction_features(
        origin, destination, date_str, time_str, weather, temperature, holiday, hist
    )

    if MODEL_MODE == "adaptive_fusion_keras":
        pred_scaled = KERAS_MODEL.predict([seq, origin_id, dest_id, weather_id, num], verbose=0)
        pred = SCALER.inverse_transform(pred_scaled)[0][0]
    else:
        seq_mean = seq.mean(axis=1, keepdims=True)
        seq_last = seq[:, -1:]
        X = np.hstack([seq_mean, seq_last, origin_id.reshape(-1, 1), dest_id.reshape(-1, 1),
                        weather_id.reshape(-1, 1), num])
        pred = FALLBACK_MODEL.predict(X)[0]

    pred = max(0, int(round(pred)))
    return pred


def historical_average(origin, destination):
    sub = DATASET[
        (DATASET["Origin_Station"] == origin) & (DATASET["Destination_Station"] == destination)
    ]
    if sub.empty:
        return None
    return round(sub["Passenger_Count"].mean(), 1)


# ---------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------
def login_required(view):
    from functools import wraps

    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


@app.route("/", methods=["GET"])
def root():
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    username = request.form.get("username", "")
    password = request.form.get("password", "")

    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    conn.close()

    if row and check_password_hash(row["password_hash"], password):
        session["user"] = username
        session["role"] = row["role"]
        return redirect(url_for("dashboard"))

    return render_template("login.html", error="Invalid username or password")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------------
# Pages
# ---------------------------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", stations=STATIONS, model_mode=MODEL_MODE, user=session.get("user"))


@app.route("/route_prediction")
@login_required
def route_prediction_page():
    return render_template("route_prediction.html", stations=STATIONS, weather_options=WEATHER_OPTIONS)


@app.route("/reports")
@login_required
def reports():
    conn = get_db()
    logs = conn.execute("SELECT * FROM prediction_log ORDER BY id DESC LIMIT 50").fetchall()
    conn.close()
    return render_template("reports.html", logs=logs)


# ---------------------------------------------------------------------
# APIs
# ---------------------------------------------------------------------
@app.route("/api/auto_predictions")
@login_required
def api_auto_predictions():
    """Automatic prediction dashboard — predicts all predefined routes now."""
    now = datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M")

    conn = get_db()
    routes = conn.execute("SELECT origin, destination FROM predefined_routes").fetchall()
    conn.close()

    results = []
    high = medium = low = 0
    for r in routes:
        pred = predict_flow(r["origin"], r["destination"], date_str, time_str, "Clear", 29.0, 0)
        level = crowd_level(pred)
        if level == "High":
            high += 1
        elif level == "Medium":
            medium += 1
        else:
            low += 1
        results.append({
            "origin": r["origin"],
            "destination": r["destination"],
            "predicted_passengers": pred,
            "crowd_level": level,
            "recommendation": recommendation_for(level),
        })

    return jsonify({
        "generated_at": now.strftime("%Y-%m-%d %H:%M"),
        "total_routes": len(results),
        "high_count": high,
        "medium_count": medium,
        "low_count": low,
        "routes": results,
    })


@app.route("/api/od_heatmap")
@login_required
def api_od_heatmap():
    """Average passenger count for every OD pair -> heatmap matrix."""
    pivot = DATASET.pivot_table(
        index="Origin_Station", columns="Destination_Station",
        values="Passenger_Count", aggfunc="mean", fill_value=0
    ).reindex(index=STATIONS, columns=STATIONS, fill_value=0)

    return jsonify({
        "stations": STATIONS,
        "matrix": pivot.round(0).values.tolist(),
    })


@app.route("/api/flow_trend")
@login_required
def api_flow_trend():
    """Hourly average passenger flow across the whole network, for the dashboard line chart."""
    df = DATASET.copy()
    df["hour"] = df["Time"].str.slice(0, 2).astype(int)
    trend = df.groupby("hour")["Passenger_Count"].mean().reindex(range(24), fill_value=0)
    return jsonify({"hours": list(range(24)), "avg_passengers": trend.round(1).tolist()})


@app.route("/api/predict", methods=["POST"])
@login_required
def api_predict():
    data = request.get_json()
    origin = data["origin"]
    destination = data["destination"]
    date_str = data["date"]
    time_str = data["time"]
    weather = data["weather"]
    temperature = float(data.get("temperature", 29.0))

    if origin == destination:
        return jsonify({"error": "Origin and destination must be different"}), 400

    holiday = 1 if data.get("holiday") else 0
    pred = predict_flow(origin, destination, date_str, time_str, weather, temperature, holiday)
    level = crowd_level(pred)
    hist_avg = historical_average(origin, destination)

    conn = get_db()
    conn.execute(
        "INSERT INTO prediction_log (origin, destination, date, time, weather, predicted_count, crowd_level) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (origin, destination, date_str, time_str, weather, pred, level),
    )
    conn.commit()
    conn.close()

    return jsonify({
        "origin": origin,
        "destination": destination,
        "predicted_passengers": pred,
        "crowd_level": level,
        "recommendation": recommendation_for(level),
        "historical_average": hist_avg,
        "model_used": MODEL_MODE,
    })


if __name__ == "__main__":
    app.run(debug=True, port=5000)
