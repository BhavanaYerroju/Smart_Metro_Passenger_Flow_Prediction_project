# Adaptive Fusion Network-Based Metro Origin–Destination Passenger Flow
# Prediction and Operational Decision Support System

A complete, runnable college mini-project: an internal tool for metro
operations staff to predict passenger flow between stations and get
crowd-management recommendations. **This is not a passenger-facing app.**

---

## 1. Folder Structure

```
metro_project/
│
├── dataset/
│   ├── generate_dataset.py       # creates the prototype dataset
│   └── metro_od_dataset.csv      # generated dataset (24,000 rows)
│
├── model/
│   ├── preprocessing.py          # shared feature engineering (train + serve)
│   ├── train_model.py            # TensorFlow/Keras Adaptive Fusion Network
│   ├── train_fallback_sklearn.py # optional: RandomForest fallback (no TF needed)
│   ├── adaptive_fusion_model.h5  # (created after running train_model.py)
│   ├── scaler.pkl                # (created after running train_model.py)
│   └── fallback_model.pkl        # (created after running the fallback trainer)
│
├── database/
│   ├── init_db.py                # creates SQLite schema + seed data
│   └── metro.db                  # (created after running init_db.py)
│
├── backend/
│   └── app.py                    # Flask application (routes, auth, ML inference, APIs)
│
├── frontend/
│   ├── templates/                # HTML pages (Jinja2)
│   │   ├── login.html
│   │   ├── dashboard.html
│   │   ├── route_prediction.html
│   │   ├── reports.html
│   │   └── _navbar.html
│   └── static/
│       ├── css/style.css
│       └── js/dashboard.js, route_prediction.js
│
├── docs/
│   └── PROJECT_REPORT.md         # documentation for project review/viva
│
└── requirements.txt
```

---

> **Backend/Frontend separation:** `backend/app.py` is configured with
> `template_folder` and `static_folder` pointing at `../frontend/`, so
> Flask serves the HTML/CSS/JS from the separate `frontend/` folder even
> though it's a server-rendered app rather than a separate SPA. This
> keeps backend logic and frontend assets in clearly separate folders
> for review, while still running as a single Flask process.

## 2. Required Software

- Python 3.10+
- pip
- A modern browser (Chrome/Edge/Firefox)
- Internet access **once**, to `pip install` dependencies (TensorFlow
  needs this)

---

## 3. Installation

From the `metro_project/` root folder:

```bash
pip install -r requirements.txt
```

This installs Flask, pandas, numpy, scikit-learn, and TensorFlow.

> If you are on a machine where TensorFlow is hard to install (e.g. no
> internet, restricted OS), you can skip it and use the lightweight
> fallback model instead — see Section 6.

---

## 4. Step-by-Step Execution

### Step 1 — Generate the dataset
```bash
python dataset/generate_dataset.py
```
Creates `dataset/metro_od_dataset.csv` (synthetic but rule-based:
peak-hour surges, weekend dips, holiday effects, weather effects,
interchange-station boosts).

### Step 2 — Initialize the database
```bash
python database/init_db.py
```
Creates `database/metro.db` with:
- `users` table → seeded with `admin` / `admin123`
- `predefined_routes` table → the 10 routes shown on the auto-dashboard
- `prediction_log` table → fills up as you use the Route Analysis page

### Step 3 — Train the Adaptive Fusion Network
```bash
python model/train_model.py
```
Trains the Keras model described in Section 7 and saves
`model/adaptive_fusion_model.h5` + `model/scaler.pkl`. Takes a few
minutes on a laptop CPU (25 epochs).

### Step 4 — Run the Flask server
```bash
python backend/app.py
```
Server starts at `http://127.0.0.1:5000/`

### Step 5 — Open in browser
Navigate to: `http://127.0.0.1:5000/`
You'll be redirected to the login page automatically.

### Step 6 — Log in
Username: `admin`
Password: `admin123`

### Step 7 — Explore
- **Dashboard** — auto-generated predictions for all 10 predefined routes
- **Route Analysis** — pick any origin/destination/date/time/weather and predict
- **Reports** — history of every prediction you've made

---

## 5. Testing a Prediction (quick check)

On the Route Analysis page:
1. Origin: `Ameerpet`, Destination: `Secunderabad`
2. Date/time: any peak-hour slot (e.g. 09:00 or 18:00)
3. Weather: `Clear`
4. Click **Predict**

Expect a **High** crowd level and a passenger count in the 500–800 range,
since Ameerpet↔Secunderabad is an interchange-heavy, high-traffic
corridor in the dataset generation rules.

---

## 6. Running Without TensorFlow (fallback mode)

If you cannot install TensorFlow, the backend still works:

```bash
python model/train_fallback_sklearn.py
python backend/app.py
```

`app.py` automatically detects whether `adaptive_fusion_model.h5`
exists. If not, it silently uses `fallback_model.pkl`
(a RandomForestRegressor trained on the same engineered features) so
the demo is never blocked. The dashboard shows which engine is active
under the summary cards.

---

## 7. Machine Learning Model — Adaptive Fusion Network

```
Data Input
   │
   ▼
Feature Processing  (time encoding, categorical encoding, scaling)
   │
   ▼
Embedding Layer      (origin station, destination station, weather)
   │
   ▼
GRU Time-Series Layer (recent passenger-count history per O-D pair)
   │
   ▼
Adaptive Fusion Layer (learned softmax attention over 5 branches:
                        sequence / origin / destination / weather / numeric)
   │
   ▼
Dense Neural Network  (64 → Dropout → 32)
   │
   ▼
Passenger Flow Prediction (single regression output)
```

The "adaptive" part: instead of simply concatenating all feature
branches, the network learns a small attention layer that outputs a
weight per branch for each prediction, then computes a weighted sum.
This lets the model lean more on the time-series branch on a normal
weekday, and more on the weather/holiday branch on an atypical day —
without hand-coding that rule.

Implemented in `model/train_model.py` using `tensorflow.keras`.

---

## 8. Notes for Project Review / Extension

- The dataset is a **prototype** — 10 stations, 60 days, rule-generated.
  In a real deployment it would be replaced with actual AFC (smart-card
  swipe) data from the metro operator, covering all stations and years
  of history.
- Admin credentials are hard-coded/seeded for demo purposes only; a
  production system would use hashed passwords with proper rotation,
  role-based access control, and audit logging (the schema already has
  a `role` column to extend this).
- The crowd-level thresholds (High ≥ 500, Medium ≥ 250, Low < 250) are
  configurable constants in `backend/app.py` (`crowd_level()`) and
  should be calibrated against real train capacity data.
