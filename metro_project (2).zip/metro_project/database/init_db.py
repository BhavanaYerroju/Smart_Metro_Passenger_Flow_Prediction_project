"""
init_db.py
----------
Creates the SQLite database used by the Flask backend:

- users            : admin/staff login accounts
- predefined_routes: the fixed set of routes shown on the automatic
                      prediction dashboard
- prediction_log    : every prediction made through the Route Analysis
                      page, kept for the Reports page / historical
                      comparison feature

Run once before starting the server:
    python database/init_db.py
"""

import sqlite3
import os
from werkzeug.security import generate_password_hash

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "metro.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'operations_admin'
);

CREATE TABLE IF NOT EXISTS predefined_routes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    origin TEXT NOT NULL,
    destination TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS prediction_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    origin TEXT NOT NULL,
    destination TEXT NOT NULL,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    weather TEXT NOT NULL,
    predicted_count INTEGER NOT NULL,
    crowd_level TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""

DEFAULT_ROUTES = [
    ("Miyapur", "Ameerpet"),
    ("Ameerpet", "Secunderabad"),
    ("KPHB", "Kukatpally"),
    ("Ameerpet", "Begumpet"),
    ("Begumpet", "Paradise"),
    ("Paradise", "Secunderabad"),
    ("Raidurg", "Hitech City"),
    ("Hitech City", "Ameerpet"),
    ("Secunderabad", "Nagole"),
    ("Miyapur", "KPHB"),
]


def main():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.executescript(SCHEMA)

    # Seed one admin account (username: admin / password: admin123)
    # NOTE: this is a prototype credential for the college demo only —
    # in a real deployment this must be changed and stored securely.
    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] == 0:
        cur.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
            ("admin", generate_password_hash("admin123"), "operations_admin"),
        )
        print("Seeded default admin user -> username: admin / password: admin123")

    cur.execute("SELECT COUNT(*) FROM predefined_routes")
    if cur.fetchone()[0] == 0:
        cur.executemany(
            "INSERT INTO predefined_routes (origin, destination) VALUES (?, ?)",
            DEFAULT_ROUTES,
        )
        print(f"Seeded {len(DEFAULT_ROUTES)} predefined routes")

    conn.commit()
    conn.close()
    print(f"Database ready at {DB_PATH}")


if __name__ == "__main__":
    main()
