# Project Report — Adaptive Fusion Network-Based Metro OD Passenger Flow
# Prediction and Operational Decision Support System

## 1. Abstract
Metro rail networks face fluctuating passenger demand across
origin–destination (OD) pairs that varies by time of day, day of week,
weather, and holidays. This project builds an internal decision-support
tool for metro operations staff that predicts OD passenger flow using a
custom "Adaptive Fusion Network" and translates predictions into
operational recommendations (train frequency, staffing) via a crowd
classification (Low / Medium / High).

## 2. Problem Statement
Manually estimating passenger demand per route is slow and reactive.
Operators need a tool that automatically forecasts flow for known busy
routes and lets them query any specific route/date/time/weather
combination on demand.

## 3. Objectives
1. Build a rule-based prototype dataset simulating realistic OD flow.
2. Design and train a fusion-based deep learning model combining
   station embeddings, temporal patterns, and contextual (weather/
   holiday) features.
3. Serve predictions through a Flask REST API.
4. Provide an admin-only web dashboard: auto predictions, OD heatmap,
   trend chart, and an on-demand Route Analysis page.
5. Log every manual prediction for later comparison (Reports page).

## 4. System Architecture

```
 Browser (Bootstrap + Chart.js)
        │  HTTP
        ▼
 Flask Backend (app.py)
        │  ├── Auth (session-based login)
        │  ├── REST APIs (/api/auto_predictions, /api/predict, ...)
        │  └── Model Inference (Keras Adaptive Fusion Network
        │       or RandomForest fallback)
        ▼
 SQLite Database (users, predefined_routes, prediction_log)
        +
 CSV Dataset (historical OD passenger counts, used for the
 sequence-window input and heatmap/trend aggregation)
```

## 5. Modules

| Module | File | Purpose |
|---|---|---|
| Dataset generation | `dataset/generate_dataset.py` | Creates prototype OD flow data |
| Feature engineering | `model/preprocessing.py` | Shared train/serve feature logic |
| Model training | `model/train_model.py` | Trains the Adaptive Fusion Network |
| Database setup | `database/init_db.py` | Creates SQLite schema + seed data |
| Backend API | `backend/app.py` | Flask routes, auth, ML inference |
| Frontend | `frontend/templates/*.html`, `frontend/static/` | Login, Dashboard, Route Analysis, Reports (HTML/CSS/JS) |

## 6. Machine Learning Approach
See README.md Section 7 for the full architecture diagram. In short:
station identity is captured via learned embeddings, recent demand
history via a GRU, and context (weather/holiday/time) via a dense
branch — combined through a learned attention-weighted fusion instead
of naive concatenation, then passed through a final dense regressor.

**Inputs:** origin station, destination station, hour (cyclical
sin/cos), day of week, temperature, weather category, holiday flag,
and the last 4 known passenger counts for that OD pair.

**Output:** predicted passenger count for that OD pair at that time.

**Loss/metric:** MSE loss, MAE metric, on a standardized target.

## 7. Database Schema

```sql
users(id, username, password_hash, role)
predefined_routes(id, origin, destination)
prediction_log(id, origin, destination, date, time, weather,
                predicted_count, crowd_level, created_at)
```

## 8. Screens
1. **Login** — username/password, restricted to operations staff.
2. **Dashboard** — 4 summary cards (total routes, high/medium/low
   crowd counts), auto-prediction table for 10 predefined routes,
   hourly network-wide trend line chart, and an OD heatmap.
3. **Route Analysis** — form (origin, destination, date, time,
   weather, holiday) → predicted count, crowd level, recommendation,
   historical-average comparison bar chart.
4. **Reports** — table of every prediction made through Route
   Analysis, most recent first.

## 9. Crowd Classification Rule
| Predicted Passengers | Level | Color | Recommendation |
|---|---|---|---|
| ≥ 500 | High | Red | Increase train frequency / deploy additional staff |
| 250–499 | Medium | Yellow | Monitor closely; keep standby train ready |
| < 250 | Low | Green | Normal operations sufficient |

(Thresholds are configurable and should be recalibrated with real train
capacity figures in production.)

## 10. Limitations & Future Scope
- Dataset is synthetic/prototype — extend with real AFC swipe-card data.
- Only 10 stations modeled — extend embeddings to the full network.
- No role-based permissions beyond a single `role` column — extend to
  full RBAC (e.g. controller vs. planner vs. viewer).
- No live weather API integration — currently manual weather selection;
  could be connected to a weather forecast API for the auto-dashboard.
- Model currently retrains offline (`train_model.py`); a production
  system would add scheduled retraining as new AFC data arrives.

## 11. Conclusion
The system demonstrates an end-to-end pipeline — synthetic data
generation, a fusion-based deep learning model, a REST backend, and an
operations-focused dashboard — that gives metro staff both an
always-on overview of network-wide crowd risk and an on-demand
what-if tool for specific routes, dates, and conditions.
