const dateInput = document.getElementById("date");
const timeInput = document.getElementById("time");
const now = new Date();
dateInput.value = now.toISOString().slice(0, 10);
timeInput.value = now.toTimeString().slice(0, 5);

let compareChart = null;

document.getElementById("predictForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const origin = document.getElementById("origin").value;
    const destination = document.getElementById("destination").value;
    if (origin === destination) {
        alert("Origin and destination must be different.");
        return;
    }

    const payload = {
        origin,
        destination,
        date: dateInput.value,
        time: timeInput.value,
        weather: document.getElementById("weather").value,
        holiday: document.getElementById("holiday").checked,
        temperature: 29.0,
    };

    const res = await fetch("/api/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (data.error) {
        alert(data.error);
        return;
    }

    document.getElementById("emptyState").style.display = "none";
    document.getElementById("resultCard").style.display = "block";

    document.getElementById("resCount").innerText = data.predicted_passengers;
    const levelEl = document.getElementById("resLevel");
    levelEl.innerText = data.crowd_level;
    levelEl.className = data.crowd_level === "High" ? "text-danger" :
                         data.crowd_level === "Medium" ? "text-warning" : "text-success";

    document.getElementById("resHist").innerText = data.historical_average ?? "N/A";
    document.getElementById("resRecommendation").innerText = "Recommendation: " + data.recommendation;

    const ctx = document.getElementById("compareChart");
    if (compareChart) compareChart.destroy();
    compareChart = new Chart(ctx, {
        type: "bar",
        data: {
            labels: ["Predicted (this request)", "Historical Average"],
            datasets: [{
                data: [data.predicted_passengers, data.historical_average ?? 0],
                backgroundColor: ["#1f4e8c", "#95a5a6"],
            }]
        },
        options: { plugins: { legend: { display: false } } }
    });
});
