function crowdBadge(level) {
    const cls = level === "High" ? "badge-high" : level === "Medium" ? "badge-medium" : "badge-low";
    return `<span class="badge ${cls}">${level}</span>`;
}

async function loadAutoPredictions() {
    const res = await fetch("/api/auto_predictions");
    const data = await res.json();

    document.getElementById("generatedAt").innerText = "Last updated: " + data.generated_at;
    document.getElementById("totalRoutes").innerText = data.total_routes;
    document.getElementById("highCount").innerText = data.high_count;
    document.getElementById("mediumCount").innerText = data.medium_count;
    document.getElementById("lowCount").innerText = data.low_count;

    const body = document.getElementById("autoTableBody");
    body.innerHTML = "";
    data.routes.forEach(r => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${r.origin} → ${r.destination}</td>
            <td>${r.predicted_passengers}</td>
            <td>${crowdBadge(r.crowd_level)}</td>
            <td>${r.recommendation}</td>
        `;
        body.appendChild(row);
    });
}

async function loadTrendChart() {
    const res = await fetch("/api/flow_trend");
    const data = await res.json();
    const ctx = document.getElementById("trendChart");
    new Chart(ctx, {
        type: "line",
        data: {
            labels: data.hours.map(h => h + ":00"),
            datasets: [{
                label: "Avg Passengers",
                data: data.avg_passengers,
                borderColor: "#1f4e8c",
                backgroundColor: "rgba(31,78,140,0.15)",
                fill: true,
                tension: 0.3,
            }]
        },
        options: { plugins: { legend: { display: false } } }
    });
}

function heatColor(value, max) {
    const ratio = max > 0 ? value / max : 0;
    if (ratio > 0.66) return "#e74c3c";
    if (ratio > 0.33) return "#f1c40f";
    if (value === 0) return "#eeeeee";
    return "#2ecc71";
}

async function loadHeatmap() {
    const res = await fetch("/api/od_heatmap");
    const data = await res.json();
    const max = Math.max(...data.matrix.flat());

    let html = '<table class="table table-bordered table-sm mb-0"><thead><tr><th></th>';
    data.stations.forEach(s => html += `<th style="font-size:0.7rem;">${s}</th>`);
    html += "</tr></thead><tbody>";

    data.stations.forEach((origin, i) => {
        html += `<tr><th style="font-size:0.7rem;">${origin}</th>`;
        data.matrix[i].forEach(val => {
            const color = heatColor(val, max);
            const text = val > 0 ? Math.round(val) : "";
            html += `<td class="heatmap-cell" style="background:${color};">${text}</td>`;
        });
        html += "</tr>";
    });
    html += "</tbody></table>";
    document.getElementById("heatmapContainer").innerHTML = html;
}

loadAutoPredictions();
loadTrendChart();
loadHeatmap();
setInterval(loadAutoPredictions, 60000); // refresh every 60s to feel "live"
