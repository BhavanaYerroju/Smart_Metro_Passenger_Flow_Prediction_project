"""
generate_dataset.py
--------------------
Creates a synthetic (prototype) Metro Origin-Destination passenger flow
dataset for Hyderabad-style metro stations.

This is a PROTOTYPE dataset built with realistic rules (peak hour boosts,
weather effects, holiday dips, distance-based base demand) so the ML
model has genuine patterns to learn. In a real deployment this file
would be replaced by actual smart-card / AFC (Automatic Fare Collection)
swipe data exported from the metro operator's systems.

Output: dataset/metro_od_dataset.csv
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

random.seed(42)
np.random.seed(42)

STATIONS = [
    "Miyapur", "KPHB", "Kukatpally", "Ameerpet", "Begumpet",
    "Paradise", "Secunderabad", "Nagole", "Raidurg", "Hitech City"
]

# Rough relative "line position" used to derive a pseudo-distance between
# stations, which drives base demand (closer + popular interchange
# stations like Ameerpet get more traffic).
POSITION = {
    "Miyapur": 0, "KPHB": 1, "Kukatpally": 2, "Ameerpet": 3, "Begumpet": 4,
    "Paradise": 5, "Secunderabad": 6, "Nagole": 8, "Raidurg": -2, "Hitech City": -1
}

INTERCHANGE_BOOST = {"Ameerpet": 1.6, "Secunderabad": 1.4, "Begumpet": 1.15}

WEATHER_OPTIONS = ["Clear", "Cloudy", "Rain", "Heavy Rain"]
WEATHER_FACTOR = {"Clear": 1.0, "Cloudy": 0.97, "Rain": 0.8, "Heavy Rain": 0.55}

HOLIDAYS_2025 = {
    "2025-01-01", "2025-01-26", "2025-03-14", "2025-04-18", "2025-05-01",
    "2025-08-15", "2025-10-02", "2025-10-21", "2025-11-01", "2025-12-25"
}


def is_peak_hour(hour: int) -> bool:
    return (8 <= hour <= 10) or (17 <= hour <= 20)


def base_demand(origin: str, destination: str) -> float:
    dist = abs(POSITION[origin] - POSITION[destination]) + 1
    demand = 900 / dist
    demand *= INTERCHANGE_BOOST.get(origin, 1.0)
    demand *= INTERCHANGE_BOOST.get(destination, 1.0)
    return demand


def generate_row(current_dt: datetime):
    origin, destination = random.sample(STATIONS, 2)
    hour = current_dt.hour
    date_str = current_dt.strftime("%Y-%m-%d")

    demand = base_demand(origin, destination)

    peak = is_peak_hour(hour)
    if peak:
        demand *= np.random.uniform(1.6, 2.1)
    elif 22 <= hour or hour <= 5:
        demand *= np.random.uniform(0.05, 0.2)
    else:
        demand *= np.random.uniform(0.6, 1.0)

    # Weekday vs weekend
    if current_dt.weekday() >= 5:
        demand *= 0.7

    holiday = 1 if date_str in HOLIDAYS_2025 else 0
    if holiday:
        demand *= 0.55

    weather = random.choices(
        WEATHER_OPTIONS, weights=[0.55, 0.25, 0.15, 0.05]
    )[0]
    demand *= WEATHER_FACTOR[weather]

    temperature = round(np.random.normal(29 if weather == "Clear" else 24, 3), 1)

    noise = np.random.normal(1.0, 0.08)
    passenger_count = max(0, int(demand * noise))

    return {
        "Date": date_str,
        "Time": current_dt.strftime("%H:%M"),
        "Origin_Station": origin,
        "Destination_Station": destination,
        "Passenger_Count": passenger_count,
        "Weather": weather,
        "Temperature": temperature,
        "Holiday": holiday,
        "Peak_Hour": 1 if peak else 0,
    }


def main(n_days: int = 60, rows_per_day: int = 400, out_path: str = "dataset/metro_od_dataset.csv"):
    start = datetime(2025, 1, 1, 0, 0)
    rows = []
    for d in range(n_days):
        day_start = start + timedelta(days=d)
        for _ in range(rows_per_day):
            hour = random.randint(4, 23)
            minute = random.choice([0, 15, 30, 45])
            ts = day_start.replace(hour=hour, minute=minute)
            rows.append(generate_row(ts))

    df = pd.DataFrame(rows)
    df.sort_values(["Date", "Time"], inplace=True)
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} rows -> {out_path}")
    print(df.head())


if __name__ == "__main__":
    main()
