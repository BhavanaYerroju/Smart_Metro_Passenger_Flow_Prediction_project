"""
train_fallback_sklearn.py
--------------------------
OPTIONAL helper — not part of the core project spec.

The core deliverable model is the TensorFlow/Keras "Adaptive Fusion
Network" in train_model.py. That script requires `pip install
tensorflow`, which needs internet access on your machine.

This script trains a RandomForestRegressor on the exact same engineered
features (station embeddings replaced by one-hot / ids, same sequence
window averaged as a feature) purely so you can run the full Flask app
end-to-end immediately, even before installing TensorFlow. Swap it out
for the real model by installing tensorflow and running train_model.py
instead — app.py automatically prefers the Keras model if it finds it.
"""

import os
import sys
import numpy as np
import pandas as pd
import joblib

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from preprocessing import build_sequences, STATIONS, WEATHER_OPTIONS

from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error


def main():
    data_path = os.path.join(os.path.dirname(__file__), "..", "dataset", "metro_od_dataset.csv")
    df = pd.read_csv(data_path)
    seq_X, origin_X, dest_X, weather_X, num_X, y = build_sequences(df)

    seq_mean = seq_X.mean(axis=1, keepdims=True)
    seq_last = seq_X[:, -1:].astype("float32")
    X = np.hstack([
        seq_mean, seq_last,
        origin_X.reshape(-1, 1), dest_X.reshape(-1, 1),
        weather_X.reshape(-1, 1), num_X
    ])

    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.15, random_state=42)

    model = RandomForestRegressor(n_estimators=200, max_depth=14, random_state=42, n_jobs=-1)
    model.fit(X_tr, y_tr)

    preds = model.predict(X_te)
    mae = mean_absolute_error(y_te, preds)
    print(f"Fallback RandomForest MAE: {mae:.2f} passengers")

    out_dir = os.path.dirname(os.path.abspath(__file__))
    joblib.dump(model, os.path.join(out_dir, "fallback_model.pkl"))
    print("Saved model/fallback_model.pkl")


if __name__ == "__main__":
    main()
