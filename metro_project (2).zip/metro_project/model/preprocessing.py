"""
preprocessing.py
-----------------
Shared feature-engineering used by BOTH the training scripts and the
Flask backend at prediction time, so train/serve feature logic never
drifts apart.
"""

import numpy as np
import pandas as pd

STATIONS = [
    "Miyapur", "KPHB", "Kukatpally", "Ameerpet", "Begumpet",
    "Paradise", "Secunderabad", "Nagole", "Raidurg", "Hitech City"
]
WEATHER_OPTIONS = ["Clear", "Cloudy", "Rain", "Heavy Rain"]

STATION_TO_ID = {s: i for i, s in enumerate(STATIONS)}
WEATHER_TO_ID = {w: i for i, w in enumerate(WEATHER_OPTIONS)}

WINDOW = 4  # number of past timesteps fed to the sequence branch


def add_time_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    dt = pd.to_datetime(df["Date"] + " " + df["Time"])
    hour = dt.dt.hour + dt.dt.minute / 60.0
    df["hour_sin"] = np.sin(2 * np.pi * hour / 24)
    df["hour_cos"] = np.cos(2 * np.pi * hour / 24)
    df["dow"] = dt.dt.dayofweek
    df["_dt"] = dt
    return df


def encode_categoricals(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["origin_id"] = df["Origin_Station"].map(STATION_TO_ID)
    df["destination_id"] = df["Destination_Station"].map(STATION_TO_ID)
    df["weather_id"] = df["Weather"].map(WEATHER_TO_ID)
    return df


def build_sequences(df: pd.DataFrame):
    """
    Group rows by OD pair, sort by time, and build sliding windows of
    WINDOW past passenger counts -> predict the next one. Returns numpy
    arrays ready for model input.
    """
    df = add_time_features(df)
    df = encode_categoricals(df)
    df = df.sort_values(["Origin_Station", "Destination_Station", "_dt"])

    seq_X, origin_X, dest_X, weather_X, num_X, y = [], [], [], [], [], []

    for (_, _), group in df.groupby(["Origin_Station", "Destination_Station"]):
        counts = group["Passenger_Count"].values
        if len(group) <= WINDOW:
            continue
        rows = group.reset_index(drop=True)
        for i in range(WINDOW, len(rows)):
            window = counts[i - WINDOW:i]
            seq_X.append(window)
            origin_X.append(rows.loc[i, "origin_id"])
            dest_X.append(rows.loc[i, "destination_id"])
            weather_X.append(rows.loc[i, "weather_id"])
            num_X.append([
                rows.loc[i, "hour_sin"], rows.loc[i, "hour_cos"],
                rows.loc[i, "Temperature"], rows.loc[i, "Holiday"],
                rows.loc[i, "Peak_Hour"], rows.loc[i, "dow"] / 6.0,
            ])
            y.append(rows.loc[i, "Passenger_Count"])

    return (
        np.array(seq_X, dtype="float32"),
        np.array(origin_X, dtype="int32"),
        np.array(dest_X, dtype="int32"),
        np.array(weather_X, dtype="int32"),
        np.array(num_X, dtype="float32"),
        np.array(y, dtype="float32"),
    )


def single_prediction_features(origin, destination, date_str, time_str, weather, temperature, holiday, history_counts):
    """
    Build a single inference-time feature set matching the training
    schema, given the last `WINDOW` known passenger counts for this OD
    pair (history_counts) as the sequence input.
    """
    dt = pd.to_datetime(f"{date_str} {time_str}")
    hour = dt.hour + dt.minute / 60.0
    hour_sin = np.sin(2 * np.pi * hour / 24)
    hour_cos = np.cos(2 * np.pi * hour / 24)
    dow = dt.dayofweek

    peak_hour = 1 if (8 <= dt.hour <= 10 or 17 <= dt.hour <= 20) else 0

    seq = np.array(history_counts[-WINDOW:], dtype="float32").reshape(1, WINDOW)
    origin_id = np.array([STATION_TO_ID[origin]], dtype="int32")
    dest_id = np.array([STATION_TO_ID[destination]], dtype="int32")
    weather_id = np.array([WEATHER_TO_ID.get(weather, 0)], dtype="int32")
    num = np.array([[hour_sin, hour_cos, temperature, holiday, peak_hour, dow / 6.0]], dtype="float32")

    return seq, origin_id, dest_id, weather_id, num
