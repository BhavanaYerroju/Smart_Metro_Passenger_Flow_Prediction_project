"""
train_model.py
---------------
Trains the "Adaptive Fusion Network" for Metro Origin-Destination
passenger flow prediction.

Architecture (matches the project spec):

    Data Input
      -> Feature Processing (time, weather, holiday, categorical encode)
      -> Embedding Layer (origin station, destination station, weather)
      -> GRU Time-Series Layer (recent passenger-count history per OD pair)
      -> Adaptive Fusion Layer (learned attention weights that combine
         the sequence branch, the two station-embedding branches, the
         weather-embedding branch, and the dense numeric-feature branch)
      -> Dense Neural Network
      -> Passenger Flow Prediction (regression, single value)

Run:
    python model/train_model.py

Outputs:
    model/adaptive_fusion_model.h5   (trained Keras model)
    model/scaler.pkl                (target scaler)
"""

import os
import sys
import numpy as np
import pandas as pd
import joblib

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from preprocessing import build_sequences, STATIONS, WEATHER_OPTIONS, WINDOW

import tensorflow as tf
from tensorflow.keras import layers, Model
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def build_adaptive_fusion_model(n_stations, n_weather, n_numeric, window=WINDOW):
    # ---- Inputs ----
    seq_in = layers.Input(shape=(window,), name="sequence_input")
    origin_in = layers.Input(shape=(1,), name="origin_input")
    dest_in = layers.Input(shape=(1,), name="destination_input")
    weather_in = layers.Input(shape=(1,), name="weather_input")
    numeric_in = layers.Input(shape=(n_numeric,), name="numeric_input")

    # ---- Embedding layer ----
    origin_emb = layers.Embedding(n_stations, 8, name="origin_embedding")(origin_in)
    origin_emb = layers.Flatten()(origin_emb)

    dest_emb = layers.Embedding(n_stations, 8, name="destination_embedding")(dest_in)
    dest_emb = layers.Flatten()(dest_emb)

    weather_emb = layers.Embedding(n_weather, 4, name="weather_embedding")(weather_in)
    weather_emb = layers.Flatten()(weather_emb)

    # ---- GRU time-series layer over recent passenger-count history ----
    seq_reshaped = layers.Reshape((window, 1))(seq_in)
    seq_repr = layers.GRU(32, name="gru_timeseries")(seq_reshaped)

    # ---- Dense branch for numeric/contextual features ----
    numeric_repr = layers.Dense(16, activation="relu")(numeric_in)

    # Project every branch to a common dimension so they can be fused
    common_dim = 16
    seq_p = layers.Dense(common_dim, activation="relu")(seq_repr)
    origin_p = layers.Dense(common_dim, activation="relu")(origin_emb)
    dest_p = layers.Dense(common_dim, activation="relu")(dest_emb)
    weather_p = layers.Dense(common_dim, activation="relu")(weather_emb)
    numeric_p = layers.Dense(common_dim, activation="relu")(numeric_repr)

    # ---- Adaptive Fusion Layer ----
    # Stack the 5 branch representations and learn a softmax attention
    # weight per branch, conditioned on all branches together. This lets
    # the network adaptively emphasise (e.g.) the time-series branch
    # during normal days and the weather/holiday branch on anomalous
    # days, instead of using a fixed concatenation.
    stacked = layers.Concatenate()([seq_p, origin_p, dest_p, weather_p, numeric_p])
    attention_logits = layers.Dense(5, name="fusion_attention_logits")(stacked)
    attention_weights = layers.Softmax(name="fusion_attention_weights")(attention_logits)

    branches = layers.Lambda(lambda x: tf.stack(x, axis=1))(
        [seq_p, origin_p, dest_p, weather_p, numeric_p]
    )  # (batch, 5, common_dim)
    weights_expanded = layers.Reshape((5, 1))(attention_weights)
    fused = layers.Multiply()([branches, weights_expanded])
    fused = layers.Lambda(lambda x: tf.reduce_sum(x, axis=1), name="adaptive_fusion_output")(fused)

    # ---- Final dense network ----
    x = layers.Dense(64, activation="relu")(fused)
    x = layers.Dropout(0.2)(x)
    x = layers.Dense(32, activation="relu")(x)
    output = layers.Dense(1, activation="linear", name="passenger_flow_prediction")(x)

    model = Model(
        inputs=[seq_in, origin_in, dest_in, weather_in, numeric_in],
        outputs=output,
        name="Adaptive_Fusion_Network",
    )
    model.compile(optimizer="adam", loss="mse", metrics=["mae"])
    return model


def main():
    data_path = os.path.join(os.path.dirname(__file__), "..", "dataset", "metro_od_dataset.csv")
    df = pd.read_csv(data_path)
    print(f"Loaded dataset: {df.shape}")

    seq_X, origin_X, dest_X, weather_X, num_X, y = build_sequences(df)
    print(f"Built {len(y)} training sequences")

    scaler = StandardScaler()
    y_scaled = scaler.fit_transform(y.reshape(-1, 1)).flatten()

    (seq_tr, seq_te, o_tr, o_te, d_tr, d_te, w_tr, w_te,
     n_tr, n_te, y_tr, y_te) = train_test_split(
        seq_X, origin_X, dest_X, weather_X, num_X, y_scaled,
        test_size=0.15, random_state=42
    )

    model = build_adaptive_fusion_model(
        n_stations=len(STATIONS), n_weather=len(WEATHER_OPTIONS), n_numeric=num_X.shape[1]
    )
    model.summary()

    model.fit(
        [seq_tr, o_tr, d_tr, w_tr, n_tr], y_tr,
        validation_data=([seq_te, o_te, d_te, w_te, n_te], y_te),
        epochs=25, batch_size=64, verbose=2
    )

    loss, mae = model.evaluate([seq_te, o_te, d_te, w_te, n_te], y_te, verbose=0)
    print(f"Test MSE(scaled): {loss:.4f}  MAE(scaled): {mae:.4f}")

    out_dir = os.path.dirname(os.path.abspath(__file__))
    model.save(os.path.join(out_dir, "adaptive_fusion_model.h5"))
    joblib.dump(scaler, os.path.join(out_dir, "scaler.pkl"))
    print("Saved model/adaptive_fusion_model.h5 and model/scaler.pkl")


if __name__ == "__main__":
    main()
